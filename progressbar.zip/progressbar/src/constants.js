export const MAX = 100
export const MIN = 0