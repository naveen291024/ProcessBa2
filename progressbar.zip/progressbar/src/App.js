import './App.css';
import ProgressBar from './components/progressbar';
import { useEffect, useState } from 'react';

function App() {

  const [value,setValue] = useState(0);
  const [success,setSuccess] = useState(false);
  
  useEffect(()=>{
     setInterval(()=>{
       setValue((val)=>val+1);
     },100);
  },[]);

  return (
    <div className='app'>
      <div>The Progress Bar</div>
      <ProgressBar value={value} onComplete={()=>setSuccess(true)}/>
      {success ? "Completed!" : "Loading!"}
    </div>
  );
}

export default App;
